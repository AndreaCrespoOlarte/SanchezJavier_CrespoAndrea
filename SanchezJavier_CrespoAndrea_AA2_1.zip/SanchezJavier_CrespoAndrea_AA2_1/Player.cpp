#include <windows.h>
#include "Player.h"
void Player::Move ( Vector2 newPos ) //Movimiento del jugador
{
    position = newPos;
}